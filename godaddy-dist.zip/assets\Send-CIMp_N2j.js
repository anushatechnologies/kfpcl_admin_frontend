import{k as s,j as t}from"./index-AnfmnB37.js";const a=s(t.jsx("path",{d:"M2.01 21 23 12 2.01 3 2 10l15 2-15 2z"}));export{a as S};
